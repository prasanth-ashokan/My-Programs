export const environment = {
    production: false,
    fbColor: 'purple'
};
